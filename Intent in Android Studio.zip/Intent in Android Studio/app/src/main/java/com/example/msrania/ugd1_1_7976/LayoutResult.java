package com.example.msrania.ugd1_1_7976;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class LayoutResult extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout_result);
       // Button hasil =(Button) findViewById(R.id.btnlihat);
        TextView text = (TextView) findViewById(R.id.txtHasil);

        Bundle b = new Bundle();
        String nama = b.getString("nama");
        String npm = b.getString("npm");
        String spinner = b.getString("spinner");
        text.setText("Mahasiswa yang bernama : " + nama+
                "dengan NPM: " +npm+ "mengambil penjurusan:  " +spinner );
        Intent i = new Intent(getApplicationContext(),LayoutResult.class);
       startActivity(i);


    }



}
