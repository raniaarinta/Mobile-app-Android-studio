package com.example.msrania.ugd1_1_7976;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class LayoutForm extends AppCompatActivity {
 EditText edit_nama,edit_npm;
    Spinner spinner;
    Button hasil;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout_form);

        hasil =(Button) findViewById(R.id.btnlihat);
       edit_nama = (EditText) findViewById(R.id.editTextNama);
        edit_npm = (EditText) findViewById(R.id.editTextNpm);
        spinner = (Spinner) findViewById(R.id.spinner);
//        EditText edit =(EditText) findViewById(R.)
        hasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               // startActivityForResult(i,0);
                Bundle b = new Bundle();

                b.putString("nama",edit_nama.getText().toString());
                b.putString("npm",edit_npm.getText().toString());
                b.putString("spinner",spinner.getSelectedItem().toString());
                Intent i = new Intent(getApplicationContext(),LayoutResult.class);
                //i.putExtra(b);
                i.putExtras(b);
                startActivity(i);
            }


        });







    }
}
